# AI Model Proxy Forward - Distribution Package

## Version
v1.0.0-1-g60be324-dirty

## Quick Start

### Directory Structure

```
dist/
├── config/
│   ├── server.yaml         # Server config template
│   └── agent.yaml         # Agent config template
├── libs/
│   ├── forward-server-v1.0.0-1-g60be324-dirty.jar
│   └── forward-agent-v1.0.0-1-g60be324-dirty.jar
├── start.bat              # Windows startup script
├── start.sh              # Linux startup script
└── README.txt
```

### Deployment Steps

1. Configure Server
   Copy config/server.yaml to config/my-server.yaml and edit

2. Configure Agent
   Copy config/agent.yaml to config/my-agent.yaml and edit

3. Start Server
   # Windows
   start.bat server config\\my-server.yaml
   # Linux
   ./start.sh server config/my-server.yaml

4. Start Agent
   # Windows
   start.bat agent config\\my-agent.yaml
   # Linux
   ./start.sh agent config/my-agent.yaml

### Test

curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "X-Auth-Token: your-token" \
  -d "{\"model\": \"gpt-4\", \"messages\": [{\"role\": \"user\", \"content\": \"Hello!\"}]}"

## Security Warning

> Production environment must use HTTPS!
> Do not use HTTP in production, otherwise tokens will be intercepted!

## License

MIT License
